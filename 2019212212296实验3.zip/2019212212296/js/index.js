const eleName = (e) => {return document.getElementById(e)};
const qSelect = (e) => {return document.querySelector(e)};
const qSelectAll = (e) => {return document.querySelectorAll(e)};
const eleCreate = (e) => {return document.createElement(e)};
var lst = qSelectAll("li");

lst[0].onclick = function() {
  alert("p1");
  eleName("p1").style.color = "red";
}

lst[1].onclick = function() {
  alert("p2");
  let now = new Date();
  let year = now.getFullYear();
  let month = now.getMonth();
  let day = now.getDate();
  qSelect("h1").innerHTML = year + "-" + month + "-" + day;
}

lst[2].onclick = function() {
  alert("p3");
  eleName("p3").classList.add('fn-active');
}

lst[3].onclick = function() {
  alert("p4");
  p8.remove();
}

lst[4].onclick = function() {
  alert("p5");
  window.open('https://uland.taobao.com/sem/tbsearch?refpid=mm_26632360_8858797_29866178&keyword=%E5%A5%B3%E8%A3%85&clk1=9b59a633f935421fcfa0e0f2d7a51ea1&upsId=9b59a633f935421fcfa0e0f2d7a51ea1');
}

lst[5].onclick = function() {
  alert("p6");
  let p9Li = eleCreate("li");
  p9Li.textContent = 'p9';
  qSelect("ul").append(p9Li);
      p9Li.onclick = function () {
        alert('p9');
      }
}

lst[6].onclick = function() {
  alert("p7");
}

lst[7].onclick = function() {
  alert("p8");
  qSelect(".m-box").style.width = screen.availWidth+'px';
}
