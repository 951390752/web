//jquery
$(document).ready(function (){
    //part1
    $(".box_1").click(function () {
        $(".box_big_1").animate({
            opacity:'1',
          });
        $(".box_big_1").removeClass("hide");
    });
    $(".box_big_1").click(function () {
        $(".box_big_1").animate({
            opacity:'0',
          });
        $(".box_big_1").addClass("hide");
    });

    //part2
    $(".m-tab").click(function () {
        $(".m-tab").removeClass("bg");
        $(this).addClass("bg");
    });
    $(".tab_1").click(function () {
        $(".m-ms").addClass("hide");
        $(".tab").children().eq(3).removeClass("hide");
    });
    $(".tab_2").click(function () {
        $(".m-ms").addClass("hide");
        $(".tab").children().eq(4).removeClass("hide");
    });
    $(".tab_3").click(function () {
        $(".m-ms").addClass("hide");
        $(".tab").children().eq(5).removeClass("hide");
    });

    //part3
    var se = 1;
    $(".m-at_1").click(function () {
        if(se > 6){
            se = se - 1;
        }
        $(".table").children().eq(se).removeClass("hide");
        se = se + 1;
    });
    $(".m-line_3").click(function () {
        se = se - 1;
         $(this).parent().addClass("hide");
    });

});
//native
// document.getElementsByClassName("box_2").onclick = function p1() {
//     alert("1");
//     document.getElementsByClassName("box_2").style.color = "red";
// };
